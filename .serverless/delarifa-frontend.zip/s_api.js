
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'daniloferrari2000',
  applicationName: 'delarifa-frontend-app',
  appUid: 'RyWW7mNc2mGWQnVTzc',
  orgUid: 'gnxrcX98CHYdK8lvDD',
  deploymentUid: '276185ce-1341-4a73-a30e-12f182d1f868',
  serviceName: 'delarifa-frontend',
  shouldLogMeta: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'production',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.6',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'delarifa-frontend-production-api', timeout: 10 };

try {
  const userHandler = require('./lambda.js');
  module.exports.handler = serverlessSDK.handler(userHandler.universal, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}